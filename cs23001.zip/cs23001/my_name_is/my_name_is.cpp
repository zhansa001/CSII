//Sandy Zhang
//my_name_is
//CS 23001
//Due Date: August 30, 2024

#include <iostream>
using std::cin; using std::cout; using std::endl;

int main() {
cout << "My name is Sandy Zhang." << endl;

return 0;
}
