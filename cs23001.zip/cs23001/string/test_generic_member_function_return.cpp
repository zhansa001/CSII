//  String class test program
// 
//  Tests: XXX
//
  
#include "string.hpp"
#include <cassert>
#include <iostream> 
 
//===========================================================================
int main ()
{
    {
        //------------------------------------------------------
        // SETUP FIXTURE
        String  str(X);

        // TEST
        RESULT_TYPE result = str.OP();

        // VERIFY
        assert(str    == X);
        assert(result == X);
    }

    {
        //------------------------------------------------------
        // SETUP FIXTURE
        String  str(X);

        // TEST
        RESULT_TYPE result = str.OP();

        // VERIFY
        assert(str    == X);
        assert(result == X);
    }

    {
        //------------------------------------------------------
        // SETUP FIXTURE
        String  str(X);

        // TEST
        RESULT_TYPE result = str.OP();

        // VERIFY
        assert(str    == X);
        assert(result == X);
    }

    {
        //------------------------------------------------------
        // SETUP FIXTURE
        String  str(X);

        // TEST
        RESULT_TYPE result = str.OP();

        // VERIFY
        assert(str    == X);
        assert(result == X);
    }

    {
        //------------------------------------------------------
        // SETUP FIXTURE
        String  str(X);

        // TEST
        RESULT_TYPE result = str.OP();

        // VERIFY
        assert(str    == X);
        assert(result == X);
    }

    {
        //------------------------------------------------------
        // SETUP FIXTURE
        String  str(X);

        // TEST
        RESULT_TYPE result = str.OP();

        // VERIFY
        assert(str    == X);
        assert(result == X);
    }

    // ADD ADDITIONAL TESTS AS NECESSARY
    
    std::cout << "Done testing XXX." << std::endl;
    return 0;
}

