/**
 * @brief  Application to run sorting algorithms on random int data
 *
 * @author Dale Haverstock
 * @date   2012-04-19
 */

// sort library
//

//==============================================================================
#include "sort_lib.h"
#include <vector>

//==============================================================================
// Make shorter type names
typedef std::vector<int>::size_type Vec_Idx;

//==============================================================================
// Function declarations, uppercase so those stand out
void quick_sort(std::vector<int>& data, int left, int right);
void SWAP(int& n1, int& n2);
bool LESS_THAN(int n1, int n2);
bool GREATER_THAN(int n1, int n2);

//==============================================================================
#include "profile.hpp"
extern profile sort_lib_cpp;

void quick_sort(std::vector<int>& data)
{
    sort_lib_cpp.count(__LINE__, "quick_sort"); // Do nothing if empty vector
    if (sort_lib_cpp.count(__LINE__), data.size() == 0)
        { return; }

    // Do the sort
    quick_sort(data, 0, data.size() - 1); sort_lib_cpp.count(__LINE__); 

}

//==============================================================================
// The unsigned ints cause problems here, jdx may go to -1.
// Subscripts are cast so there are no warnings.
void quick_sort(std::vector<int>& data, int left, int right)
{
      sort_lib_cpp.count(__LINE__, "quick_sort"); // Calculate the pivot
      int pivot = data[Vec_Idx((left + right) / 2)];

      // Partition
      int idx = left;
      int jdx = right;
      while (sort_lib_cpp.count(__LINE__), idx <= jdx) {
            while (sort_lib_cpp.count(__LINE__), LESS_THAN(data[Vec_Idx(idx)], pivot)) {
                idx++; sort_lib_cpp.count(__LINE__); 

            }
            while (sort_lib_cpp.count(__LINE__), GREATER_THAN(data[Vec_Idx(jdx)], pivot)) {
                jdx--; sort_lib_cpp.count(__LINE__); 

            }

            if (sort_lib_cpp.count(__LINE__), idx <= jdx)
            {
                  SWAP(data[Vec_Idx(idx)], data[Vec_Idx(jdx)]); sort_lib_cpp.count(__LINE__); 

                  idx++; sort_lib_cpp.count(__LINE__); 

                  jdx--; sort_lib_cpp.count(__LINE__); 

            }
      }

      // Recurse
      if (sort_lib_cpp.count(__LINE__), left < jdx)
            { quick_sort(data, left, jdx); sort_lib_cpp.count(__LINE__); 
 }

      if (sort_lib_cpp.count(__LINE__), idx < right)
            { quick_sort(data, idx, right); sort_lib_cpp.count(__LINE__); 
 }
}

//==============================================================================
void selection_sort(std::vector<int>& data)
{
    sort_lib_cpp.count(__LINE__, "selection_sort"); // Do nothing if empty vector (note unsigned 0 - 1 is a big number)
    if (sort_lib_cpp.count(__LINE__), data.size() == 0)
        { return; }

    // Index of last element in vector, also last in unsorted part
    Vec_Idx last = data.size() - 1;

    // Do the sort
    while (sort_lib_cpp.count(__LINE__), last > 0)
    {
        // Find greatest in unsorted part
        Vec_Idx idx_of_greatest = 0;
        for (Vec_Idx idx = 0; sort_lib_cpp.count(__LINE__), idx <= last; ++idx)
        {
            if ( sort_lib_cpp.count(__LINE__), LESS_THAN(data[idx_of_greatest], data[idx]) )
            {
                // Remember as new greatest so far
                idx_of_greatest = idx; sort_lib_cpp.count(__LINE__); 

            }
        }

        // Swap last in unsorted with greatest in unsorted part
        SWAP(data[last], data[idx_of_greatest]); sort_lib_cpp.count(__LINE__); 


        // Increase sorted part
        --last; sort_lib_cpp.count(__LINE__); 

    }
}

//==============================================================================
void bubble_sort(std::vector<int>& data)
{
    sort_lib_cpp.count(__LINE__, "bubble_sort"); // Go through vector repeatedly
    for(Vec_Idx limit = data.size(); sort_lib_cpp.count(__LINE__), limit > 0; limit--)
    {
        // Go through vector once, swap element and next element if out of order
        for(Vec_Idx idx = 0; sort_lib_cpp.count(__LINE__), idx < limit - 1; idx++)
        {
            if( sort_lib_cpp.count(__LINE__), LESS_THAN(data[idx + 1], data[idx]) )
            {
                SWAP(data[idx],data[idx + 1]); sort_lib_cpp.count(__LINE__); 

            }
        }
    }
}

//==============================================================================
// This is here so the number of calls can be counted.
void SWAP(int& n1, int& n2)
{
    sort_lib_cpp.count(__LINE__, "SWAP"); std::swap(n1, n2); sort_lib_cpp.count(__LINE__); 

}

//==============================================================================
// This is here so the number of calls can be counted.
bool LESS_THAN(int n1, int n2)
{
    sort_lib_cpp.count(__LINE__, "LESS_THAN"); return n1 < n2;
}

//==============================================================================
// This is here so the number of calls can be counted.
bool GREATER_THAN(int n1, int n2)
{
    sort_lib_cpp.count(__LINE__, "GREATER_THAN"); return n1 > n2;
}


